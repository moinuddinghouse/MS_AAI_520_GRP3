# Multi-Agent Investment Research System — Streamlit deployment

This Streamlit entry point wraps the team's existing orchestration function in `web/server.py`. It keeps the original `src/financial_mcp_server.py`, specialist agents, evaluator/optimizer loop, and FAISS memory implementation. It does not require running a separate FastAPI server for the Streamlit UI.

## Deploy to Streamlit Community Cloud

1. Upload the files and folders from this package to the root of your GitHub repository. Keep `app.py`, `requirements.txt`, `web/`, `src/`, and `memory/` in their relative paths.
2. In Streamlit Community Cloud, choose the repository and set **Main file path** to `app.py`.
3. Deploy. The current deterministic workflow uses Yahoo Finance and its existing MCP tool functions. If you later enable a Google ADK/Gemini model call, add `GOOGLE_API_KEY` through Streamlit **Settings → Secrets**; do not hardcode secrets in code or GitHub.
4. Run a test with `AAPL`, then test a second ticker and another period. Check news availability, evaluator iterations, and execution logs.

## Local run

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
streamlit run app.py
```

## Notes and limitations

- Streamlit Cloud's filesystem is ephemeral; JSON/FAISS memory may not persist across restarts.
- Yahoo Finance/news calls can be delayed, incomplete, or rate-limited.
- If no news articles are returned, the app explicitly reports that instead of claiming verified news coverage.
- The team's existing evaluator and specialist scores are heuristic process outputs, not validated return forecasts or investment advice.
- This package is syntax-checked, but must be deployed and run end-to-end in Streamlit Cloud to validate its external data calls and package compatibility.

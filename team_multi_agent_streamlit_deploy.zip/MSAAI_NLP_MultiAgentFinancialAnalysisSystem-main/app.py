"""Streamlit interface for the MSAAI multi-agent financial research project.

This UI calls the team's existing orchestration function; it does not replace the
specialists, MCP financial tools, evaluator/optimizer, or FAISS memory implementation.
"""
from __future__ import annotations
import asyncio
import sys
from pathlib import Path
from typing import Any

import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parent
WEB_DIR = ROOT / "web"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(WEB_DIR) not in sys.path:
    sys.path.insert(0, str(WEB_DIR))

st.set_page_config(page_title="Multi-Agent Investment Research", page_icon="📈", layout="wide")

st.title("📈 Multi-Agent Investment Research System")
st.caption("Research Manager · Market Specialist · Earnings Specialist · News Specialist · Evaluator–Optimizer · FAISS Memory · FastMCP")
st.info("Educational demonstration only. Financial data may be delayed or incomplete. This application does not provide personalized investment advice.")

@st.cache_resource(show_spinner=False)
def load_backend():
    # The original FastAPI backend contains the team's existing execution workflow.
    import server  # web/server.py, added to sys.path above
    return server

with st.sidebar:
    st.header("Research setup")
    ticker = st.text_input("Stock ticker", value="AAPL", max_chars=12).strip().upper()
    period_label = st.selectbox("Historical pricing window", ["1 month", "3 months", "6 months", "1 year", "2 years", "5 years"], index=2)
    period_map = {"1 month": "1mo", "3 months": "3mo", "6 months": "6mo", "1 year": "1y", "2 years": "2y", "5 years": "5y"}
    period = period_map[period_label]
    run = st.button("🚀 Run Multi-Agent Orchestrator", type="primary", use_container_width=True)
    st.divider()
    st.caption("The first run may take time while Yahoo Finance and news sources respond. Gemini is optional in the current deterministic workflow.")

if "research_result" not in st.session_state:
    st.session_state.research_result = None

if run:
    if not ticker or not ticker.replace(".", "").replace("-", "").isalnum():
        st.error("Enter a valid ticker symbol, such as AAPL, NVDA, or JPM.")
    else:
        try:
            backend = load_backend()
            request = backend.FullExecutionRequest(ticker=ticker, period=period)
            with st.spinner(f"Running the existing multi-agent workflow for {ticker}…"):
                result = asyncio.run(backend.execute_full_orchestration(request))
            st.session_state.research_result = result
        except Exception as exc:
            st.error("The research run failed. Check dependency versions and the Streamlit logs for details.")
            st.exception(exc)

result: dict[str, Any] | None = st.session_state.research_result
if result:
    st.divider()
    st.subheader(f"Research report: {result.get('ticker', ticker)} — {result.get('company_name', '')}")
    st.caption(f"Execution time: {result.get('execution_time_sec', 'N/A')} seconds · Data is retrieved when you run the analysis.")

    market = result.get("mcp_data", {}).get("market", {}) or {}
    financials = result.get("mcp_data", {}).get("financials", {}) or {}
    news = result.get("mcp_data", {}).get("news", []) or []
    score = result.get("composite_score")
    stance = result.get("consensus_stance", "Not available")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Specialist consensus score", f"{score}/100" if score is not None else "N/A")
    c2.metric("Consensus label", str(stance))
    c3.metric("Latest price", f"${market['current_price']:,.2f}" if isinstance(market.get("current_price"), (int, float)) else "Unavailable")
    c4.metric("Period return", f"{market['period_return_pct']:+.2f}%" if isinstance(market.get("period_return_pct"), (int, float)) else "Unavailable")

    if "simulat" in str(market).lower() or "simulat" in str(financials).lower():
        st.warning("Some returned data may be simulated or fallback data. Verify source fields before interpreting this report.")

    st.subheader("1. Market analysis")
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Annualized volatility", f"{market['annualized_volatility_pct']:.2f}%" if isinstance(market.get("annualized_volatility_pct"), (int, float)) else "N/A")
    m2.metric("RSI (14-day)", str(market.get("rsi_14", "N/A")))
    m3.metric("50-day SMA", f"${market['sma_50']:,.2f}" if isinstance(market.get("sma_50"), (int, float)) else "N/A")
    m4.metric("200-day SMA", f"${market['sma_200']:,.2f}" if isinstance(market.get("sma_200"), (int, float)) else "N/A")
    st.write("**Trend signal:**", market.get("trend_signal", "Unavailable"))
    history = market.get("history")
    if isinstance(history, list) and history:
        try:
            df = pd.DataFrame(history)
            if "date" in df.columns and "close" in df.columns:
                df["date"] = pd.to_datetime(df["date"], errors="coerce")
                df = df.dropna(subset=["date"]).sort_values("date").set_index("date")
                st.line_chart(df[["close"]], y_label="Price")
        except Exception:
            pass

    st.subheader("2. Earnings and fundamentals")
    fcols = st.columns(4)
    fundamental_fields = [
        ("Operating margin", "operating_margin_pct", "%"),
        ("Revenue growth YoY", "revenue_growth_yoy_pct", "%"),
        ("Return on equity", "return_on_equity_pct", "%"),
        ("Debt/equity", "debt_to_equity", ""),
    ]
    for col, (label, key, suffix) in zip(fcols, fundamental_fields):
        value = financials.get(key)
        col.metric(label, f"{value}{suffix}" if isinstance(value, (int, float)) else "Unavailable")
    with st.expander("Raw financial data and source fields"):
        st.json(financials)

    st.subheader("3. News evidence")
    if news:
        st.caption(f"Retrieved {len(news)} headline(s). Headlines are evidence to inspect, not proof of causal market impact.")
        for item in news:
            if isinstance(item, dict):
                title = item.get("title", "Untitled headline")
                publisher = item.get("publisher") or item.get("source") or "Source not supplied"
                link = item.get("link") or item.get("url")
                with st.expander(str(title)):
                    st.write(f"Source: {publisher}")
                    if item.get("summary"):
                        st.write(item["summary"])
                    if link:
                        st.markdown(f"[Open source article]({link})")
                    st.json(item)
            else:
                st.write(str(item))
    else:
        st.warning("No news articles were returned for this run. The report should not be treated as having verified news evidence.")

    st.subheader("4. Specialist reports")
    reports = result.get("specialist_reports", {}) or {}
    for key, title in [("market", "Market Specialist"), ("earnings", "Earnings Specialist"), ("news", "News Specialist"), ("risk", "Risk Specialist")]:
        with st.expander(title):
            rep = reports.get(key)
            if rep:
                st.json(rep)
            else:
                st.warning("No report returned for this specialist.")

    st.subheader("5. Evaluator–optimizer review")
    opt_history = result.get("optimization_history", []) or []
    if opt_history:
        st.dataframe(pd.DataFrame(opt_history), use_container_width=True, hide_index=True)
        last = opt_history[-1]
        if last.get("passed"):
            st.success(f"The existing evaluator marked the final iteration as passed ({last.get('score')}/100). This is a process score, not prediction accuracy.")
        else:
            st.warning(f"The evaluator did not meet its acceptance threshold in the saved iterations. Final score: {last.get('score')}/100.")
    else:
        st.warning("No evaluator history was returned.")
    memo = result.get("final_investment_memo", "")
    st.subheader("6. Final research memo")
    st.markdown(memo if memo else "No final memo returned.")

    with st.expander("Execution telemetry / agent logs"):
        logs = result.get("logs", []) or []
        if logs:
            st.dataframe(pd.DataFrame(logs), use_container_width=True, hide_index=True)
        else:
            st.info("No execution logs were returned.")

    with st.expander("Raw result JSON"):
        st.json(result)

    st.download_button(
        "Download research report (JSON)",
        data=__import__("json").dumps(result, indent=2, default=str),
        file_name=f"{result.get('ticker', ticker)}_multi_agent_research.json",
        mime="application/json",
    )
else:
    st.markdown("### Ready to run")
    st.write("Choose a ticker and lookback period in the sidebar, then run the orchestrator. The interface calls the team's existing execution function in `web/server.py` and presents its returned data, specialist reports, optimizer iterations, and logs.")
    st.warning("No report has been generated in this session yet. The metrics shown after execution come from the returned workflow result, not static dashboard placeholders.")

st.divider()
st.caption("Educational demonstration only · Data providers may rate-limit requests · Historical indicators are not forecasts or personalized investment advice.")
